/*******************************************************************************
 * This file is part of Bombeirb.
 * Copyright (C) 2018 by Laurent Réveillère
 ******************************************************************************/
#include <assert.h>
#include <time.h>
#include <game.h>
#include <misc.h>
#include <window.h>
#include <sprite.h>
#include <stdio.h>
#define CELL(i,j) ( (i) + (j) * map_get_width(game_get_current_map(game)) )

struct game {
  struct map** maps;       // the game's map
  short max_levels;        // nb maps of the game
  short current_level;
  short current_world;
  struct player* player;
  struct bomb** bomb;
  struct monster** monster;
  int pause;
  int pause_time;   //SDL_GetTicks() when u press P
  int rmpause_time;
  int prev_pausetime;
  int total_pausetime;

};

struct game* game_new(void) {
	sprite_load(); // load sprites into process memory
	struct game* game = malloc(sizeof(struct game));
  game->current_world =1;
  game_load_level(game,game->current_world);

  game->pause = 0;
  game->total_pausetime = 0;
  game->prev_pausetime = 0;
  game->rmpause_time = 0;
  game->pause_time = 0;

	int H=map_get_height(game->maps[game->current_level]);
	int W=map_get_width(game->maps[game->current_level]);
	game->bomb = malloc(sizeof(struct bomb*)*W*H);
	game->monster = malloc(sizeof(struct monster*)*W*H);
	for(int i=0;i<H*W;i++)
	  game->bomb[i] = NULL;
	for(int i=0;i<H*W;i++)
	  game->monster[i] = NULL;

	struct monster* monster = new_monster(game_get_current_map(game),game->player);
	int i = monster_get_x(monster);
	int j = monster_get_y(monster);
	game->monster[CELL(i,j)] = monster;
	struct monster* monster2 = new_monster(game_get_current_map(game),game->player);
	i = monster_get_x(monster2);
	j = monster_get_y(monster2);
	game->monster[CELL(i,j)] = monster2;
	return game;
}

int game_load_level(struct game* game,int level_n){
  struct player* player=game->player;
  char name[50];
  strcpy(name,"data/level_");
  name[11] = '0' + level_n;
  name[12] = '\0';
  int x;
  int y;
  int n;
  char map_name[50];
  FILE * level_file = fopen(name,"r");
  strcpy(map_name,"map/");
  fscanf(level_file,"%d",&game->max_levels);
  fscanf(level_file,"%d:%d,%d",&game->current_level,&x,&y);
  fscanf(level_file,"%s",map_name+4);
  game->maps = malloc(sizeof(struct map*) * game->max_levels);
  n = strlen(map_name);
  map_name[n] = '_';
  map_name[n+2] = '\0';

  for(int i=0; i<game->max_levels;i++){
    map_name[n+1] = '0' + i;
    game->maps[i] = map_load_file(map_name);
  }
  int a, b, c, d;
  if (level_n==0) {
    fscanf(level_file,"%d %d %d %d",&a,&b,&c,&d);
    player_set_fnb_bomb(player,a);
    player_set_nbkeys(player,b);
    player_set_lives(player,c);
    player_set_bomb_range(player,d);
  }
  game->player = player_init(2,0);
  player_set_position(game->player, x, y);
  return 0;
}

static void save_game(struct game* game) {
  struct player* player = game -> player;
  short current_world = game->current_level;
  FILE* sfile = NULL;
  sfile = fopen("data/level_0","w");
  fprintf(sfile,"%d\n",game->max_levels);
  fprintf(sfile,"%d:%d,%d\nsave\n",current_world,player_get_x(player),player_get_y(player));
  char smap_name[50];
  strcpy(smap_name,"map/save_");
  for (int i=0;i<game->max_levels;i++) {
    smap_name[10] = '\0';
    smap_name[9] = '0' + i;
    FILE* file = NULL;
    printf("hh");
    file = fopen(smap_name,"w");
    map_save(game->maps[i],file);
    fclose(file);
  }
  int bombs = player_get_fnb_bomb(player);
  int keys = player_get_nb_key(player);
  int lives = player_get_lives(player);
  int range = player_get_bomb_range(player);
  fprintf(sfile,"%d %d %d %d",bombs,keys,lives,range);
  fclose(sfile);
}


void game_free(struct game* game) {
	assert(game);

	player_free(game->player);
	for (int i = 0; i < game->max_levels; i++)
		map_free(game->maps[i]);
}

struct monster* game_get_monster(struct game* game, int x, int y) {
  assert(game);
  return game->monster[CELL(x,y)];
}


struct map* game_get_current_map(struct game* game) {
	assert(game);
	return game->maps[game->current_level];
}
void game_set_level(struct game* game ,int N) {
  game -> current_level = N;
}

struct player* game_get_player(struct game* game) {
	assert(game);
	return game->player;
}

void game_banner_display(struct game* game) {
	assert(game);

	struct map* map = game_get_current_map(game);

	int y = (map_get_height(map)) * SIZE_BLOC;
	for (int i = 0; i < map_get_width(map); i++)
		window_display_image(sprite_get_banner_line(), i * SIZE_BLOC, y);

	int white_bloc = ((map_get_width(map) * SIZE_BLOC) - 10 * SIZE_BLOC) / 4;

	int x = 0;
	y = (map_get_height(map) * SIZE_BLOC) + LINE_HEIGHT;
	window_display_image(sprite_get_banner_life(), x, y);

	x = SIZE_BLOC;
	window_display_image(sprite_get_number(player_get_lives(game->player)), x, y);

	x = white_bloc + 2 * SIZE_BLOC;
	window_display_image(sprite_get_banner_bomb(), x, y);

	x =  white_bloc + 3 * SIZE_BLOC;
	window_display_image(sprite_get_number(player_get_nb_bomb(game->player)), x, y);

	x = 2 * white_bloc + 4 * SIZE_BLOC;
	window_display_image(sprite_get_banner_range(), x, y);

	x = 2 * white_bloc + 5 * SIZE_BLOC;
	window_display_image(sprite_get_number(player_get_bomb_range(game->player)), x, y);

 x = 3 * white_bloc + 6 * SIZE_BLOC;
 window_display_image(sprite_get_key(),x,y);

	x = 4 * white_bloc + 8 * SIZE_BLOC;
	window_display_image(sprite_get_banner_flag(), x, y);

	x = 4 * white_bloc + 9 * SIZE_BLOC;
	window_display_image(sprite_get_number(game->current_level), x, y);

	x = 3 * white_bloc + 7 * SIZE_BLOC;

	window_display_image(sprite_get_number(player_get_nb_key(game->player)), x, y);

}

void game_display(struct game* game) {
	assert(game);
	window_clear();
	game_banner_display(game);
	map_display(game_get_current_map(game));
	player_display(game->player);
	game_display_bombs(game);
	game_display_monsters(game);
	window_refresh();
}


int game_get_total_pausetime(struct game* game) {
  assert(game);
  return game->total_pausetime;
}



static short input_keyboard(struct game* game) {
	SDL_Event event;
	struct player* player = game_get_player(game);
	struct map* map = game_get_current_map(game);
	int move = 0;
	while (SDL_PollEvent(&event)) {
		switch (event.type) {
		case SDL_QUIT:
			return 1;
		case SDL_KEYDOWN:
			switch (event.key.keysym.sym) {
        case SDLK_KP1:
        game_load_level(game,1);
        break;
        case SDLK_KP2:
        game_load_level(game,2);
        break;
      case SDLK_s:
      save_game(game);
      break;
      case SDLK_l:
      game_load_level(game,0);
      break;
			case SDLK_ESCAPE:
				return 1;
      case SDLK_p:
      if (game->pause==1) {
        game->pause=0;
        if (game->rmpause_time==0)
          game->rmpause_time = SDL_GetTicks();
        else
          game->rmpause_time = SDL_GetTicks()-(game->rmpause_time - game->prev_pausetime);
        game->total_pausetime += game->rmpause_time - game->pause_time;
      }
      else {
        game->pause=1;
        game->prev_pausetime = game-> pause_time;
        if (game->pause_time==0)
          game->pause_time = SDL_GetTicks();
        else
          game->pause_time = SDL_GetTicks()-(game->rmpause_time - game->pause_time);
      }
      break;
      default:
      break;
    }
    if (game->pause==0) {
      switch (event.key.keysym.sym) {
			case SDLK_UP:
				player_set_current_way(player, NORTH);
				move=player_move(player, map);

				break;
			case SDLK_DOWN:
				player_set_current_way(player, SOUTH);
				move=player_move(player, map);

				break;
			case SDLK_RIGHT:
				player_set_current_way(player, EAST);
				move=player_move(player, map);

				break;
			case SDLK_LEFT:
				player_set_current_way(player, WEST);
				move=player_move(player, map);

				break;
			case SDLK_SPACE:     ////////BOMB////////
			  if (player_get_nb_bomb(player)>0 && map_get_cell_type(map,player_get_x(player),player_get_y(player))!=CELL_DOOR) {
			    game_put_bomb(game);
			  }
				break;

			default:
				break;
			}
    }

			break;
		}
	}
  int old_level = game->current_level;
	if (move>=2) {
	  game_set_level(game,move-2);
	  struct map* newmap = game_get_current_map(game);
	  int pos = map_search_door(newmap,old_level);
	  struct player* newplayer =  game_get_player(game);
	  int x = map_get_x(newmap,pos);
	  int y = map_get_y(newmap,pos);
	  player_set_position(newplayer,x,y);
	}

	return 0;
}





int game_update(struct game* game) {
  if (input_keyboard(game) == 1)
		return 1; // exit game
  if (game->pause == 1)
    return 0;
  struct map* map = game_get_current_map(game);
  struct bomb* bomb = NULL;
  struct player* player = game_get_player(game);
  player_set_RET(player,SDL_GetTicks()-player_get_timer(player));

  int H = map_get_height(map);
  int W = map_get_width(map);
  int a=0;
  int x = player_get_x(player);
  int y = player_get_y(player);

  if(map_get_cell_type(map,x,y)==EXPLOSION && player_get_immunity(player)==0) {

      if(player_get_lives(player)>0)
        player_dec_lives(player);
      player_set_immunity(player,1);
      player_set_timer(player,SDL_GetTicks());
}

  if(player_get_RET(player)>=1000) {
    player_set_timer(player,SDL_GetTicks());
    player_set_immunity(player,0);
}
  for (int j=0; j<W*H; j++) {
    bomb = game->bomb[j];
    if (bomb != NULL) {
      bomb_update_age(game,bomb);
      a++;
    }
  }
  game_update_monsters(game);
  player_set_nb_bomb(player,player_get_fnb_bomb(player)-a);
  return 0;
}

void game_update_monsters(struct game* game) {
  struct map* map = game_get_current_map(game);
  struct player* player = game_get_player(game);
  int H = map_get_height(map);
  int W = map_get_width(map);
  struct monster* monster = NULL;
  for (int j=0; j<W*H; j++) {
    monster = game->monster[j];
    if (monster != NULL) {
      monster_set_age(monster,SDL_GetTicks()-monster_get_birth(monster));
      if (monster_get_age(monster)>500) {
	monster_move(monster,monster_get_map(monster),player);
	monster_set_birth(monster,SDL_GetTicks());
      }
      int mx = monster_get_x(monster);
      int my = monster_get_y(monster);
      if (CELL(mx,my)!=j) {
	game->monster[CELL(mx,my)] = monster;
	game->monster[j] = NULL;
      }
      if(player_get_x(player)==mx && player_get_y(player)==my && player_get_immunity(player)==0) {
          if(player_get_lives(player)>0)
            player_dec_lives(player);
          player_set_immunity(player,1);
          player_set_timer(player,SDL_GetTicks());
    }
      if (map_get_cell_type(map,mx,my)==EXPLOSION)
	game->monster[CELL(mx,my)] = NULL;
    }
  }

}


void game_display_bombs(struct game* game) {
  struct map* map = game_get_current_map(game);
  struct bomb* bomb = NULL;
  int H = map_get_height(map);
  int W = map_get_width(map);
  for (int j=0; j<W*H; j++) {
    bomb = game->bomb[j];
    if (bomb != NULL) {
      game_bomb_display(game,bomb);
    }
  }
}

void game_display_monsters(struct game* game) {
  struct map* map = game_get_current_map(game);
  struct monster* monster = NULL;
  int H = map_get_height(map);
  int W = map_get_width(map);
  for (int j=0; j<W*H; j++) {
    monster = game->monster[j];
    if (monster != NULL && monster_get_map(monster)==map) {
      monster_display(monster);
    }
  }
}

void game_set_bomb(struct game* game, struct bomb* bomb, int i) {
  assert(game);
  game -> bomb[i] = bomb;
}

struct bomb* game_get_bomb(struct game* game, int i) {
  assert(game);
  return game->bomb[i];
}


void game_bomb_display(struct game* game,struct bomb* bomb) {
  struct map* map = bomb_get_map(bomb);
  int age = bomb_get_age(bomb);
  int x = bomb_get_x(bomb);
  int y = bomb_get_y(bomb);
  if (age < 1000)
    map_set_cell(map,x,y,BOMB_4);
  else if (age >= 1000 && age <2000)
    map_set_cell(map,x,y,BOMB_3);
  else if (age >= 2000 && age <3000)
    map_set_cell(map,x,y,BOMB_2);
  else if (age >= 3000 && age <4000)
    map_set_cell(map,x,y,BOMB_1);
  else if (age >=4000 && age<5000)
    game_explode_bomb(game,bomb);
  else
    game_end_explosion(game,bomb);
}
