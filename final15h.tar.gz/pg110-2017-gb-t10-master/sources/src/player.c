/*******************************************************************************
 * This file is part of Bombeirb.
 * Copyright (C) 2018 by Laurent Réveillère
 ******************************************************************************/
#include <SDL/SDL_image.h>
#include <assert.h>
#include <bomb.h>
#include <player.h>
#include <sprite.h>
#include <window.h>
#include <misc.h>
#include <constant.h>

struct player {
  int x, y;
  enum direction current_direction;
  int nb_bombs;
  int fixed_nb_bombs;
  int nb_keys;
  int bomb_range;
  int lives;
  int timer;
  int RET;    //resist explosion time
  int immunity;
};



void player_set_nbkeys(struct player* player,int b) {
  assert(player);
  player->nb_keys = b;
}
void player_set_lives(struct player* player, int c) {
  assert(player);
  player->lives = c;
}

struct player* player_init(int bomb_number, int key_number) {
	struct player* player = malloc(sizeof(*player));
	if (!player)
		error("Memory error");
	player->timer = SDL_GetTicks();
	player->RET = 0;
	player->current_direction = SOUTH;
	player->fixed_nb_bombs = bomb_number;
	player->nb_bombs = bomb_number;
	player->nb_keys = key_number;
	player->bomb_range = 2;
	player -> lives = 2;
  player->immunity = 0;
	return player;
}


void player_set_RET(struct player* player,int ret) {
  assert(player);
  player->RET = ret;
}
void player_set_timer(struct player* player,int t) {
  assert(player);
  player->timer = t;
}

int player_get_RET(struct player* player) {
  assert(player);
  return player->RET;
}

int player_get_timer(struct player* player) {
  assert(player);
  return player->timer;
}


void player_set_immunity(struct player* player,int i) {
  assert(player);
  player->immunity = i;
}

int player_get_immunity(struct player* player) {
  assert(player);
  return player->immunity;
}



////////player lives //////////
void player_dec_lives(struct player* player) {
	assert(player);
	player->lives -= 1;
}

void player_inc_lives(struct player* player) {
	assert(player);
	player->lives += 1;
}

int player_get_lives(struct player* player) {
	assert(player != NULL);
	return player->lives;
}
////////////////////////////////


void player_set_position(struct player *player, int x, int y) {
	assert(player);
	player->x = x;
	player->y = y;
}


void player_free(struct player* player) {
	assert(player);
	free(player);
}

int player_get_x(struct player* player) {
	assert(player != NULL);
	return player->x;
}

int player_get_y(struct player* player) {
	assert(player != NULL);
	return player->y;
}


void player_set_current_way(struct player* player, enum direction way) {
	assert(player);
	player->current_direction = way;
}
////////// nb_bombs ///////////
int player_get_nb_bomb(struct player* player) {
	assert(player);
	return player->nb_bombs;
}

void player_set_nb_bomb(struct player* player, int n) {
	assert(player);
	player->nb_bombs = n;
}

void player_inc_nb_bomb(struct player* player) {
	assert(player);
	player->nb_bombs += 1;
}

void player_dec_nb_bomb(struct player* player) {
	assert(player);
	player->nb_bombs -= 1;
}

//////fixed nb bombs////////
int player_get_fnb_bomb(struct player* player) {
	assert(player);
	return player->fixed_nb_bombs;
}

void player_set_fnb_bomb(struct player* player, int n) {
	assert(player);
	player->fixed_nb_bombs = n;
}

void player_inc_fnb_bomb(struct player* player) {
	assert(player);
	player->fixed_nb_bombs += 1;
}

void player_dec_fnb_bomb(struct player* player) {
	assert(player);
	player->fixed_nb_bombs -= 1;
}

/////////////// bomb range /////////////
int player_get_bomb_range(struct player* player) {
	assert(player);
	return player->bomb_range;
}

void player_set_bomb_range(struct player* player,int range) {
	assert(player);
	player->bomb_range = range;
}

void player_dec_bomb_range(struct player* player) {
	assert(player);
	player->bomb_range -= 1;
}

void player_inc_bomb_range(struct player* player) {
	assert(player);
	player->bomb_range += 1;
}
/////////////////////////////////////////////



void player_inc_nb_key(struct player* player) {
	assert(player);
	player->nb_keys += 1;
}

void player_dec_nb_key(struct player* player) {
	assert(player);
	player->nb_keys -= 1;
}
int player_get_nb_key(struct player* player) {
  assert(player);
  return player ->nb_keys;
}

static void player_use_bonus(struct player* player,struct map* map, int x, int y) {
  switch(map_get_full_cell_type(map,x,y)&0x0f) {
  case BONUS_BOMB_RANGE_DEC:
    player_dec_bomb_range(player);
    break;
  case BONUS_BOMB_RANGE_INC:
    player_inc_bomb_range(player);
    break;
  case BONUS_BOMB_NB_DEC:
    if(player_get_nb_bomb(player)>0)
      player_dec_fnb_bomb(player);
    break;
  case BONUS_BOMB_NB_INC:
    player_inc_fnb_bomb(player);
    break;
  case BONUS_LIFE:
    player_inc_lives(player);
    break;
  }
}

static int player_move_box(struct player* player, struct map* map, int x, int y) {
        int pos_x = player -> x;
        int pos_y = player -> y;   //current position of player
        //player wants to reach position x,y where there's a box
        int nx = 2*x - pos_x;
	int ny = 2*y - pos_y;
        if (!map_is_inside(map,nx,ny))
                return 0;
        if (map_get_cell_type(map,nx,ny) != CELL_EMPTY)
                return 0;
        char box = map_get_full_cell_type(map,nx,ny);
        map_set_cell(map, x, y, box);
        map_set_cell_type(map,nx,ny,CELL_BOX);
        return 1;
}

static int player_move_aux(struct player* player, struct map* map, int x, int y) {

	if (!map_is_inside(map, x, y))
		return 0;
	switch (map_get_cell_type(map, x, y)) {
	case CELL_SCENERY:
	  return 0;
	  break;

	case CELL_BOX:
	  return player_move_box(player,map,x,y);
	  break;

	case CELL_BONUS:
	  player_use_bonus(player,map,x,y);
	  break;

	case CELL_DOOR: {
	  if (map_get_door_state(map,x,y)==DOOR_OPEN)
	    return 2+ map_next_level(map_get_full_cell_type(map,x,y));
	  else {
		    if(player->nb_keys > 0) {
		      map_change_door_state(map,x,y);
		      player_dec_nb_key(player);
		    }
		    return 1;
	  }
	}
	  break;
	case CELL_KEY:
	   player_inc_nb_key(player);
	  break;
	default:
		break;
	}

	// Player has moved
	return 1;
}

int player_move(struct player* player, struct map* map) {
	int x = player->x;
	int y = player->y;
	int move = 0;
	int p;
	switch (player->current_direction) {
	case NORTH: {
	  p=player_move_aux(player, map, x, y - 1);
		if (p) {
			player->y--;
			move = 1;
		}
	}
		break;

	case SOUTH: {
	  p=player_move_aux(player, map, x, y + 1);
		if (p) {
			player->y++;
			move = 1;
		}
	}
		break;


	case WEST: {
	  p=player_move_aux(player, map, x - 1, y);
		if (p) {
			player->x--;
			move = 1;
		}
	}
		break;

	case EAST: {
	  p=player_move_aux(player, map, x + 1, y);
		if (p) {
			player->x++;
			move = 1;
		}
 	}
		break;
	}
	if (p>=2)
	  return p;
     	if (move && (map_get_cell_type(map,x,y) == CELL_KEY || map_get_cell_type(map,x,y) == CELL_BONUS) ) {  //for keys & bonus
	  map_set_cell_type(map, x, y, CELL_EMPTY);
	}


	return move;
}

void player_display(struct player* player) {
	assert(player);
	window_display_image(sprite_get_player(player->current_direction),
			player->x * SIZE_BLOC, player->y * SIZE_BLOC);
}
