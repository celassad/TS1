#include <SDL/SDL_image.h>
#include <assert.h>
#include <bomb.h>
#include <monster.h>
#include <sprite.h>
#include <window.h>
#include <misc.h>
#include <constant.h>


struct monster {
  struct map* map;
  int x,y;
  enum direction current_direction;
  int birth;
  int age;
};

struct monster* new_monster(struct map* map,struct player* player) {

  int H = map_get_height(map);
  int W = map_get_width(map);
  struct monster* monster = malloc(sizeof(*monster));
  monster -> x = rand() % W;
  monster -> y = rand() % H;
  monster -> birth = SDL_GetTicks();
  monster -> age = 0;
  while (map_get_cell_type(map,monster->x,monster->y)!=CELL_EMPTY && (player_get_x(player)!=monster->x || player_get_y(player)!=monster->y)) {
    monster -> x = rand() % W;
    monster -> y = rand() % H;
  }
  monster -> current_direction = rand() % 4;
  monster -> map = map;
  return monster;
}

int monster_get_birth(struct monster* monster) {
  assert(monster);
  return monster -> birth;
}

void monster_set_age(struct monster* monster, int age) {
  assert(monster);
  monster -> age = age;
}

void monster_set_birth(struct monster* monster, int birth) {
  assert(monster);
  monster -> birth = birth;
}

int monster_get_age(struct monster* monster) {
  assert(monster);
  return monster -> age;
}

int monster_get_x(struct monster* monster) {
  assert(monster);
  return monster -> x;
}

int monster_get_y(struct monster* monster) {
  assert(monster);
  return monster -> y;
}

struct map* monster_get_map(struct monster* monster) {
  assert(monster);
  return monster -> map;
}

void monster_display(struct monster* monster) {
	assert(monster);
	window_display_image(sprite_get_monster(monster->current_direction),SIZE_BLOC*monster->x,SIZE_BLOC*monster->y);
	//	map_set_cell(monster->map,monster->x,monster->y,CELL_MONSTER|monster->current_direction);
}

static int monster_move_aux(struct monster* monster, struct map* map,struct player* player, int x, int y) {
  int direction = monster->current_direction;
  if (!map_is_inside(map, x, y)) {
    while(monster->current_direction == direction)
      monster -> current_direction = rand()%4;
    return 0;
  }

  /*if(player_get_x(player)==x && player_get_y(player)==y) {
    while(monster->current_direction == direction)
      monster -> current_direction = rand()%4;
    return 0;
  }*/

  if(map_get_cell_type(map, x, y)==CELL_EMPTY)
    return 1;


  while (monster->current_direction == direction)
    monster -> current_direction = rand()%4;
  return 0;

}


int monster_move(struct monster* monster, struct map* map,struct player* player) {
	int x = monster->x;
	int y = monster->y;
	int move = 0;
	int p;
	switch (monster->current_direction) {
	case NORTH: {
	  p=monster_move_aux(monster, map,player, x, y - 1);
		if (p) {
			monster->y--;
			move = 1;
		}
	}
		break;

	case SOUTH: {
	  p=monster_move_aux(monster, map,player, x, y + 1);
		if (p) {
			monster->y++;
			move = 1;
		}
	}
		break;


	case WEST: {
	  p=monster_move_aux(monster, map, player, x - 1, y);
		if (p) {
			monster->x--;
			move = 1;
		}
	}
		break;

	case EAST: {
	  p=monster_move_aux(monster, map, player, x + 1, y);
		if (p) {
			monster->x++;
			move = 1;
		}
 	}
		break;
	}
	if (move==1)
	  map_set_cell_type(map,x,y,CELL_EMPTY);
	return move;
}
