/*******************************************************************************
 * This file is part of Bombeirb.
 * Copyright (C) 2018 by Laurent Réveillère
 ******************************************************************************/
#include <SDL/SDL_image.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <map.h>
#include <constant.h>
#include <misc.h>
#include <sprite.h>
#include <window.h>
#include <bomb.h>

struct map {
  int width;
  int height;
  unsigned char* grid;
  struct bomb* bomb;
};


#define CELL(i,j) ( (i) + (j) * map->width)


struct map* map_new(int width, int height)
{
	assert(width > 0 && height > 0);
	struct map* map = malloc(sizeof *map);
	if (map == NULL )
		error("map_new : malloc map failed");
	map->width = width;
	map->height = height;
	map->grid = malloc(height * width);
	map -> bomb = NULL;
	if (map->grid == NULL) {
		error("map_new : malloc grid failed");
	}

	// Grid cleaning
	int i, j;
	for (i = 0; i < width; i++)
	  for (j = 0; j < height; j++) {
	    map->grid[CELL(i,j)] = CELL_EMPTY;
	  }
	return map;
}

int map_is_inside(struct map* map, int x, int y)   //returns 1 if cell(x,y) is inside the map
{
        assert(map);
        if ( (x>=0) && (x<(map->width)) && (y>=0) && (y<(map->height)))
		return 1;
        else
		return 0;
}
void map_free(struct map *map)
{
	if (map == NULL )
		return;
	free(map->grid);
	free(map);
}

int map_get_width(struct map* map)
{
	assert(map != NULL);
	return map->width;
}

int map_get_height(struct map* map)
{
  	assert(map);
	return map->height;
}

enum cell_type map_get_cell_type(struct map* map, int x, int y)
{
	assert(map && map_is_inside(map, x, y));
	return map->grid[CELL(x,y)] & 0xf0;
}

unsigned char map_get_full_cell_type(struct map* map, int x, int y) {
        assert(map && map_is_inside(map, x, y));
	return map->grid[CELL(x,y)];
}

enum door_state map_get_door_state(struct map* map, int x, int y) {
  assert(map && map_is_inside(map, x, y));
	return map->grid[CELL(x,y)] & 0x01;
}

void map_change_door_state(struct map* map, int x, int y) {
    assert(map && map_is_inside(map, x, y));
    char T = map_get_full_cell_type(map,x,y);
    enum door_state state = map_get_door_state(map,x,y);
    if (state == DOOR_OPEN)
      T--;
    else
      T++;
    map_set_cell(map,x,y,T);
}

void map_set_cell_type(struct map* map, int x, int y, enum cell_type type)
{
	assert(map && map_is_inside(map, x, y));
	map->grid[CELL(x,y)] = type;
}

void map_set_cell(struct map* map, int x, int y, unsigned char type)
{
        assert(map && map_is_inside(map, x, y));
        map->grid[CELL(x,y)] = type;
}


void display_bonus(struct map* map, int x, int y, unsigned char type)
{
	// bonus is encoded with the 4 most significant bits
	switch (type & 0x0f) {
	case BONUS_BOMB_RANGE_INC:
		window_display_image(sprite_get_bonus(BONUS_BOMB_RANGE_INC), x, y);
		break;

	case BONUS_BOMB_RANGE_DEC:
		window_display_image(sprite_get_bonus(BONUS_BOMB_RANGE_DEC), x, y);
		break;

	case BONUS_BOMB_NB_DEC:
		window_display_image(sprite_get_bonus(BONUS_BOMB_NB_DEC), x, y);
		break;

	case BONUS_BOMB_NB_INC:
		window_display_image(sprite_get_bonus(BONUS_BOMB_NB_INC), x, y);
		break;
	case BONUS_LIFE:
	  window_display_image(sprite_get_bonus(BONUS_LIFE),x,y);
	  break;
	}
}

void display_scenery(struct map* map, int x, int  y, unsigned char type)
{
	switch (type & 0x0f) { // sub-types are encoded with the 4 less significant bits
	case SCENERY_STONE:
		window_display_image(sprite_get_stone(), x, y);
		break;

	case SCENERY_TREE:
		window_display_image(sprite_get_tree(), x, y);
		break;
	}
}
///////////////////BOMB//////////////
void display_bomb(struct map* map, int x, int y, unsigned char type) {
  switch (type) {
  case BOMB_1:
     window_display_image(sprite_get_bomb(1),x,y);
     break;

  case BOMB_2:
     window_display_image(sprite_get_bomb(2),x,y);
     break;

  case BOMB_3:
     window_display_image(sprite_get_bomb(3),x,y);
     break;

  case BOMB_4:
     window_display_image(sprite_get_bomb(4),x,y);
     break;
  }
}


void map_display(struct map* map)
{
	assert(map != NULL);
	assert(map->height > 0 && map->width > 0);

	int x, y;
	for (int i = 0; i < map->width; i++) {
	  for (int j = 0; j < map->height; j++) {
	    x = i * SIZE_BLOC;
	    y = j * SIZE_BLOC;

	    unsigned char type = map->grid[CELL(i,j)];

	    switch (type & 0xf0) {
	    case CELL_SCENERY:
	      display_scenery(map, x, y, type);
	      break;
	    case CELL_BOX:
	      window_display_image(sprite_get_box(), x, y);
	      break;
	    case CELL_BONUS:
	      display_bonus(map, x, y, type);
	      break;
	    case CELL_KEY:
	      window_display_image(sprite_get_key(), x, y);
	      break;
	    case CELL_DOOR:    ///gestion des portes///
	      {
		if ((type & 1) == 1)
		  window_display_image(sprite_get_door_opened(),x,y);
		else
		  window_display_image(sprite_get_door_closed(),x,y);
	      };
	      break;
	    case CELL_BOMB:    ///////bombs//////
	      display_bomb(map,x,y,type);
	      break;
	    case EXPLOSION:
	      window_display_image(sprite_get_explosion(),x,y);
	      break;
	    }
	  }
	}
}

void map_save(struct map* map,FILE* file) {
  unsigned char* grid = map->grid;
  int H = map->height;
  int W = map->width;
  fprintf(file,"%dx%d\n",H,W);
  for (int i=0;i<H;i++)
    for (int j=0;j<W;j++) {
      fprintf(file,"%d ",map->grid[CELL(i,j)]);
    }
}


struct map* map_load_file(char* file){
        FILE* pfile = fopen(file, "r");
        if (pfile == NULL) {
                printf("couldn't open file");
                return NULL;
        }
        int H, W;
        fscanf(pfile,"%d x %d",&W,&H);
	int b;
	struct map* map = map_new(W,H);
        for (int j=0;j<H;j++) {
                for(int i=0;i<W;i++) {
			               fscanf(pfile,"%d ",&b);
                     map->grid[CELL(j,i)] = b;
                }
	}
        fclose(pfile);
        return map;
        }

int  map_next_level(char T) {
  T = T & 0x0e;     // & 0000 1110= 14  = 0000 xxx0
  T = T >> 1;     // 0000 0xxx
  return T;
}

int map_search_door(struct map* map, int level) {
   int W = map_get_width(map);
   int H = map_get_height(map);
   for (int i=0;i<W;i++)
     for (int j=0;j<H;j++) {
       if (map_get_cell_type(map,i,j) == CELL_DOOR){
	 char T = map_get_full_cell_type(map,i,j);
	 if (map_next_level(T)==level)
	   return CELL(i,j);
       }
     }
   return 0;    //returns the cell number of door leading to level 'level'
}


int map_get_y(struct map* map,int cell) {
  int W = map_get_width(map);
  int y=0;
  while(cell>W-1) {
    cell = cell-W;
    y++;
  }
  return y;
}

int map_get_x(struct map* map,int cell) {
  int W = map_get_width(map);
  int y=0;
  while(cell>W-1) {
    cell = cell-W;
    y++;
  }
  return cell;
}
